package com.example.graph;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.github.mikephil.charting.animation.Easing;
import com.github.mikephil.charting.charts.HorizontalBarChart;
import com.github.mikephil.charting.data.BarData;
import com.github.mikephil.charting.data.BarDataSet;
import com.github.mikephil.charting.data.BarEntry;

import java.util.ArrayList;

public class BarActivity extends AppCompatActivity {

    HorizontalBarChart nChart;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        nChart = (HorizontalBarChart) findViewById(R.id.barchart);
        setData(12, 50);
    }

    private void setData(int count, int range){

        ArrayList<BarEntry> yVals = new ArrayList<>();
        float barWidth = 9f;
        float spaceForBar = 10f;

        for(int i=0; i<count; i++){
            float val = (float) (Math.random()*range);
            yVals.add(new BarEntry(i*spaceForBar,val));
        }

        BarDataSet set1;
        set1 = new BarDataSet(yVals,"나트륨");

        BarData data = new BarData(set1);
        data.setBarWidth(barWidth);

        nChart.animateY(2500, Easing.EasingOption.EaseInOutCubic);
        nChart.setData(data);
    }
}
